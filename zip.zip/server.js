import express from "express";
import bodyParser from "body-parser";
import session from "express-session";
import cookieParser from "cookie-parser"; 
import userRoutes from "./routes/userRoutes.js";
import videosRoutes from "./routes/articles.js";

const server = express();

server.use(bodyParser());
server.use(bodyParser.json());
server.use(cookieParser());
server.use(express.static("public"));


server.set("view engine", "ejs");

server.use("/users", userRoutes);

server.use("videos", videosRoutes);

server.listen(5000, () => {
  console.log("server is running on port 5000");
});
