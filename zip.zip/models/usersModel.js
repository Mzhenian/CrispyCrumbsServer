function checkUsernameAndPassword(username, password) {
  for (const user of users) {
    if (username === user.username && password === user.password) {
      return true;
    }
  }
  return false;
}

export { checkUsernameAndPassword };
