const articles = [
  { id: 1, title: "Hello", content: "world" },
  { id: 2, title: "Hello2", content: "world2" },
  { id: 3, title: "Hello3", content: "world3" },
];

const getArticles = () => {
  return articles;
};

export { getArticles };
