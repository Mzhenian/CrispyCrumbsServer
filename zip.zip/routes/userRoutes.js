import express from "express";
import { users, showUser } from "../controllers/login.js";

const router = express.Router();

router.get("/", showLoginPage); 
router.post("/", login);

export default router;
