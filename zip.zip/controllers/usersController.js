import { checkUsernameAndPassword } from "../models/usersModel.js";

const showLoginPage = (req, res) => {
  res.render("login"); // Render the login view
};

const login = (req, res) => {
  const failedAttempts = parseInt(req.cookies.failedAttempts) || 0;
  const attempts = parseInt(req.cookies.attempts) || 0;

  res.cookie("attempts", attempts + 1);

  if (failedAttempts >= 3) {
    res.end("get out of here");
  } else {
    const result = checkUsernameAndPassword(req.body.username, req.body.password);
    if (result) {
      req.session.username = req.body.username;
      res.cookie("failedAttempts", 0);
      res.redirect("/articles"); // Redirect to the articles page on successful login
    } else {
      res.cookie("failedAttempts", failedAttempts + 1);
      res.end("not welcome bad user and/or password");
    }
  }
};

function isLoggedIn(req, res, next) {
  if (req.session.username != null) {
    return next();
  } else {
    res.redirect("/login");
  }
}

export { login, showLoginPage, isLoggedIn };
